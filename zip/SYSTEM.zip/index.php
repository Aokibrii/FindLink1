<?php

session_start();

$errors = [
  'login' => $_SESSION['login_error'] ?? '',
  'register' => $_SESSION['register_error'] ?? ''
];
$activeForm = $_SESSION['active_form'] ?? 'login';

session_unset();

function showError($error)
{
  return !empty($error) ? "<p class='error-message'>$error</p>" : '';
}

function isActiveForm($formName, $activeForm)
{
  return $formName === $activeForm ? 'active' : '';
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Lost and Found</title>
  <link rel="stylesheet" href="css/style.css" />
</head>

<body>
  <div class="container">
    <div class="form-box <?= isActiveForm('login', $activeForm); ?>" id="login-form">
      <form action="login_register.php" method="post" onsubmit="return confirmLogin();">
        <h2>Login</h2>
        <?= showError($errors['login']); ?>
        <input type="email" id="login-email" name="email" placeholder="Email" required />
        <input type="password" id="password" name="password" placeholder="Password" required />
        <button type="submit" name="login" id="login-btn">Login</button>
        <img src="images/eye-close.png" alt="eye-close" id="eye-close" class="eye-icon" onclick="togglePasswordVisibility('password', 'eye-close', 'eye-open')" />
        <p>Don't have an account? <a href="#" onclick="showForm('register-form')">Register</a></p>
      </form>
    </div>
  </div>


  <div class="form-box <?= isActiveForm('register', $activeForm); ?>" id="register-form">
    <form action="login_register.php" method="post" onsubmit="return confirmRegister();">
      <h2>Register</h2>
      <?= showError($errors['register']); ?>
      <input type="text" name="name" placeholder="Name" required oninvalid="this.setCustomValidity('Please enter your name here before registering!')" oninput="this.setCustomValidity('')" />
      <input type="email" id="register-email" name="email" placeholder="Email" required />
      <input type="password" name="password" placeholder="Password" required />
      <select name="role" required>
        <option value="">--Select Role--</option>
        <option value="user">User</option>
      </select>
      <button type="submit" name="register">Register</button>
      <p>Already have an account? <a href="#" onclick="showForm('login-form')">Login</a></p>
    </form>
  </div>
  </div>

  <script src="js/script.js"></script>

</body>
<<!-- Modal -->
  <div id="myModal" class="modal">
    <div class="modal-content">
      <h2>Are you sure?</h2>
      <p>Do you really want to proceed?</p>
      <div class="modal-buttons">
        <button class="btn btn-proceed" id="proceedBtn">Proceed</button>
        <button class="btn btn-cancel" id="cancelBtn">Cancel</button>
      </div>
    </div>
  </div>

</html>