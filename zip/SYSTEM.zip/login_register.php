<?php
session_start();
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Registration
    if (isset($_POST['register'])) {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $role = trim($_POST['role'] ?? 'user');
        $created_at = date('Y-m-d H:i:s');

        if (empty($name) || empty($email) || empty($password)) {
            $_SESSION['register_error'] = 'All fields are required.';
            $_SESSION['active_form'] = 'register';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['register_error'] = 'Invalid email format.';
            $_SESSION['active_form'] = 'register';
        } elseif ($role === 'admin') {
            // Only allow admin@gmail.com as admin and only one admin
            if (strtolower($email) !== 'admin@gmail.com') {
                $_SESSION['register_error'] = 'Only admin@gmail.com can be registered as admin.';
                $_SESSION['active_form'] = 'register';
            } else {
                $stmt = $connect->prepare("SELECT * FROM users WHERE role = 'admin'");
                $stmt->execute();
                $result = $stmt->get_result();
                if ($result->num_rows > 0) {
                    $_SESSION['register_error'] = 'An admin account already exists. Only one admin is allowed.';
                    $_SESSION['active_form'] = 'register';
                } else {
                    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $connect->prepare("INSERT INTO users (name, email, password, role, created_at) VALUES (?, ?, ?, ?, ?)");
                    $stmt->bind_param("sssss", $name, $email, $hashedPassword, $role, $created_at);
                    if ($stmt->execute()) {
                        $_SESSION['success_message'] = 'Registration successful! Please log in.';
                        header("Location: index.php");
                        exit();
                    } else {
                        $_SESSION['register_error'] = 'Registration failed. Please try again.';
                    }
                }
            }
        } else {
            $stmt = $connect->prepare("SELECT email FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $_SESSION['register_error'] = 'Email is already registered!';
                $_SESSION['active_form'] = 'register';
            } else {
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $connect->prepare("INSERT INTO users (name, email, password, role, created_at) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("sssss", $name, $email, $hashedPassword, $role, $created_at);
                if ($stmt->execute()) {
                    $_SESSION['success_message'] = 'Registration successful! Please log in.';
                    header("Location: index.php");
                    exit();
                } else {
                    $_SESSION['register_error'] = 'Registration failed. Please try again.';
                }
            }
        }
        header("Location: index.php");
        exit();
    }

    // Login
    if (isset($_POST['login'])) {
        $email = trim($_POST['email'] ?? '');
        $password = trim($_POST['password'] ?? '');

        if (empty($email) || empty($password)) {
            $_SESSION['login_error'] = 'Email and Password are required.';
            $_SESSION['active_form'] = 'login';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['login_error'] = 'Invalid email format.';
            $_SESSION['active_form'] = 'login';
        } else {
            $stmt = $connect->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();
                if (password_verify($password, $user['password'])) {
                    $_SESSION['name'] = $user['name'];
                    $_SESSION['email'] = $user['email'];
                    if ($user['role'] === 'admin') {
                        header("Location: admin_page.php");
                    } else {
                        header("Location: user_page.php");
                    }
                    exit();
                } else {
                    $_SESSION['login_error'] = 'Incorrect email or password.';
                }
            } else {
                $_SESSION['login_error'] = 'Incorrect email or password.';
            }
        }
        $_SESSION['active_form'] = 'login';
        header("Location: index.php");
        exit();
    }
}
