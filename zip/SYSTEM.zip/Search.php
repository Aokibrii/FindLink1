<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit();
}

// Database connection (update with your database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$searchQuery = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $searchQuery = $conn->real_escape_string($_POST['search']);
}

if (!empty($searchQuery)) {
    $stmt = $conn->prepare("SELECT * FROM posts WHERE description LIKE ? OR title LIKE ?");
    $likeQuery = '%' . $searchQuery . '%';
    $stmt->bind_param("ss", $likeQuery, $likeQuery);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT * FROM posts");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Lost and Found Items</title>
    <link rel="stylesheet" href="css/user_page.css">
    <link rel="stylesheet" href="css/Profile.css">
    <script src="https://kit.fontawesome.com/d5b87e9fae.js" crossorigin="anonymous"></script>
</head>

<body>
    <div class="header">
        <div class="side-nav">
            <a href="user_page.php" class="logo">
                <img src="images/Icon.jpg" class="logo-img">
            </a>
            <ul class="nav-links">
                <li><a href="user_page.php"><i class="fa-solid fa-house"></i>
                        <p>Home</p>
                    </a></li>
                <li><a href="Profile.php"><i class="fa-solid fa-circle-user"></i>
                        <p>Profile</p>
                    </a></li>
                <li><a href="Search.php"><i class="fa-solid fa-magnifying-glass"></i>
                        <p>Search for Lost and Found Items</p>
                    </a></li>
                <li><a href="Post_Lost_and_Found.php"><i class="fa-solid fa-paper-plane"></i>
                        <p>Post Lost and Found Items</p>
                    </a></li>
                <li><a href="Lost.php"><i class="fa-solid fa-question"></i>
                        <p>Lost Items Feed</p>
                    </a></li>
                <li><a href="Found.php"><i class="fa-solid fa-exclamation"></i>
                        <p>Found Items Feed</p>
                    </a></li>
            </ul>
            <div class="active"></div>
        </div>
    </div>

    <div class="search-container">
        <form method="POST" action="">
            <input type="text" name="search" placeholder="Search for items..." value="<?php echo htmlspecialchars($searchQuery); ?>">
            <button type="submit">Search</button>
        </form>

        <div class="search-results">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<div class='item'>";
                    // Show image preview if available
                    if (!empty($row['photo_path'])) {
                        echo "<img src='" . htmlspecialchars($row['photo_path']) . "' alt='Item Image' class='item-img'>";
                    }
                    // Show title
                    if (!empty($row['title'])) {
                        echo "<h3>" . htmlspecialchars($row['title']) . "</h3>";
                    }
                    // Show description
                    echo "<p>" . htmlspecialchars($row['description']) . "</p>";
                    // Optionally show more info
                    if (!empty($row['location'])) {
                        echo "<p><strong>Location:</strong> " . htmlspecialchars($row['location']) . "</p>";
                    }
                    if (!empty($row['date'])) {
                        echo "<p><strong>Date:</strong> " . htmlspecialchars($row['date']) . "</p>";
                    }
                    echo "</div>";
                }
            } else {
                echo "<p>No items found.</p>";
            }
            ?>
        </div>
    </div>
    <style>
        .search-container {
            position: absolute;
            top: 60px;
            left: 300px;
            right: 0;
            margin: 0 auto;
            width: 100%;
            max-width: 700px;
            min-width: 320px;
            padding: 40px 40px 28px 40px;
            background: #fff;
            border-radius: 18px;
            box-shadow: 0 6px 32px rgba(37, 99, 235, 0.10), 0 1.5px 8px rgba(0, 0, 0, 0.04);
            z-index: 2;
            transition: box-shadow 0.2s;
        }

        .search-container form {
            display: flex;
            gap: 14px;
            margin-bottom: 32px;
            align-items: center;
        }

        .search-container input[type="text"] {
            flex: 1;
            padding: 14px 18px;
            border: 1.5px solid #d1d5db;
            border-radius: 10px;
            font-size: 1.08rem;
            transition: border 0.2s, box-shadow 0.2s;
            background: #f8fafc;
            box-shadow: 0 1px 4px rgba(37, 99, 235, 0.04);
        }

        .search-container input[type="text"]:focus {
            border: 2px solid #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.10);
            outline: none;
            background: #fff;
        }

        .search-container button {
            padding: 14px 32px;
            background: linear-gradient(90deg, #2563eb 0%, #1e40af 100%);
            color: #fff;
            border: none;
            border-radius: 10px;
            font-size: 1.08rem;
            font-weight: 700;
            cursor: pointer;
            transition: background 0.2s, transform 0.1s, box-shadow 0.2s;
            box-shadow: 0 2px 10px rgba(37, 99, 235, 0.10);
            letter-spacing: 0.01em;
        }

        .search-container button:hover,
        .search-container button:focus {
            background: linear-gradient(90deg, #1e40af 0%, #2563eb 100%);
            transform: translateY(-2px) scale(1.04);
            box-shadow: 0 4px 18px rgba(37, 99, 235, 0.13);
        }

        .search-results {
            margin-top: 18px;
        }

        .search-results .item {
            background: #f3f6fb;
            border: 1.5px solid #e0e7ef;
            border-radius: 12px;
            padding: 26px 22px;
            margin-bottom: 22px;
            display: flex;
            gap: 22px;
            align-items: flex-start;
            transition: box-shadow 0.2s, border 0.2s, background 0.2s;
            box-shadow: 0 2px 8px rgba(37, 99, 235, 0.04);
        }

        .search-results .item:hover {
            box-shadow: 0 6px 24px rgba(37, 99, 235, 0.13);
            border: 2px solid #2563eb;
            background: #e8f0fe;
        }

        .search-results .item-img {
            max-width: 120px;
            max-height: 120px;
            min-width: 90px;
            min-height: 90px;
            display: block;
            margin-right: 18px;
            border-radius: 10px;
            object-fit: cover;
            background: #e0e7ef;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
            border: 1.5px solid #dbeafe;
        }

        .search-results .item-details {
            flex: 1;
        }

        .search-results h3 {
            margin: 0 0 10px 0;
            color: #2563eb;
            font-size: 1.22rem;
            font-weight: 800;
            letter-spacing: 0.01em;
        }

        .search-results p {
            margin: 0 0 8px 0;
            color: #222;
            font-size: 1.04rem;
            line-height: 1.6;
        }

        .search-results .meta {
            color: #555;
            font-size: 0.99rem;
            margin-top: 3px;
        }

        .search-results>p {
            color: #888;
            text-align: center;
            margin-top: 40px;
            font-size: 1.12rem;
        }

        @media (max-width: 900px) {
            .search-container {
                left: 0;
                right: 0;
                max-width: 98vw;
                padding: 18px 4vw 18px 4vw;
            }

            .search-results .item {
                flex-direction: column;
                align-items: stretch;
                padding: 18px 10px;
                gap: 10px;
            }

            .search-results .item-img {
                margin: 0 auto 12px auto;
                max-width: 90vw;
                min-width: 60px;
                min-height: 60px;
            }
        }

        @media (max-width: 600px) {
            .search-container {
                padding: 10px 2vw 10px 2vw;
                min-width: unset;
                max-width: 100vw;
                border-radius: 0;
                top: 50px;
                left: 0;
            }

            .search-results .item {
                padding: 10px 4px;
            }
        }
    </style>

    <script src="js/script.js"></script>
</body>

</html>

<?php
$conn->close();
?>