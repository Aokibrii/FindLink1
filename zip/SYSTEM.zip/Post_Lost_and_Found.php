<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit();
}

$host = 'localhost';
$db   = 'user_db'; // Fixed database name
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = $_POST['description'] ?? '';
    $location = $_POST['location'] ?? '';
    $latitude = $_POST['latitude'] ?? '';
    $longitude = $_POST['longitude'] ?? '';
    $date = $_POST['date'] ?? '';
    $time = $_POST['time'] ?? '';
    $user_email = $_SESSION['email'] ?? '';
    $photo_path = '';

    if (empty($title)) {
        $errors[] = "Title is required.";
    }

    // Handle file upload
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['photo']['tmp_name'];
        $fileName = basename($_FILES['photo']['name']);
        $fileSize = $_FILES['photo']['size'];
        $fileType = $_FILES['photo']['type'];
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];

        if (!in_array($fileType, $allowedTypes)) {
            $errors[] = "Only JPG, PNG, and GIF files are allowed.";
        } elseif ($fileSize > 5 * 1024 * 1024) {
            $errors[] = "File size should not exceed 5MB.";
        } else {
            $uploadDir = 'uploads/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
            $destPath = $uploadDir . uniqid() . '_' . $fileName;
            if (move_uploaded_file($fileTmpPath, $destPath)) {
                $photo_path = $destPath;
            } else {
                $errors[] = "Failed to upload the photo.";
            }
        }
    } else {
        $errors[] = "Photo is required.";
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO posts (user_email, title, description, location, latitude, longitude, date, time, photo_path, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$user_email, $title, $description, $location, $latitude, $longitude, $date, $time, $photo_path]);
        $success = "Post submitted successfully!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lost and Found</title>
    <script src="https://kit.fontawesome.com/d5b87e9fae.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/user_page.css">
    <link rel="stylesheet" href="css/post.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <style>
        #mapModal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }

        #mapModal>div {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            max-width: 95vw;
            max-height: 95vh;
            position: relative;
            min-width: 320px;
        }

        #leafletMap {
            width: 500px;
            height: 350px;
            max-width: 90vw;
            max-height: 60vh;
        }

        @media (max-width: 600px) {
            #leafletMap {
                width: 90vw;
                height: 40vh;
            }
        }
    </style>
</head>

<body>
    <div class="header">
        <div class="header">
            <div class="side-nav">
                <a href="" class="logo">
                    <img src="images/Icon.jpg" class="logo-img">
                </a>
                <ul class="nav-links">
                    <li><a href="User_page.php"><i class="fa-solid fa-house"></i>
                            <p>Home</p>
                        </a></li>
                    <li><a href="Profile.php"><i class="fa-solid fa-circle-user"></i>
                            <p>Profile</p>
                        </a></li>
                    <li><a href="Search.php"><i class="fa-solid fa-magnifying-glass"></i>
                            <p>Search for Lost and Found Items</p>
                        </a></li>
                    <li><a href="Post_Lost_and_Found.php"><i class="fa-solid fa-paper-plane"></i>
                            <p>Post Lost and Found Items</p>
                        </a></li>
                    <li><a href="Lost.php"><i class="fa-solid fa-question"></i>
                            <p>Lost Items Feed</p>
                        </a></li>
                    <li><a href="Found.php"><i class="fa-solid fa-exclamation"></i>
                            <p>Found Items Feed</p>
                        </a></li>
                    <div class="active"></div>
            </div>
            <div>
                <main>
                    <section class="post-form-section">
                        <h2>Post Lost or Found Item</h2>
                        <!-- Preview Card -->
                        <div id="previewCard" class="preview-card" style="display:none;">
                            <img id="previewImg" src="#" alt="Image Preview" style="display:none;">
                            <div>
                                <span class="preview-label">Location:</span>
                                <span id="previewLocation"></span>
                            </div>
                        </div>
                        <?php if (!empty($errors)): ?>
                            <div style="color:red;">
                                <?php foreach ($errors as $error) echo "<p>$error</p>"; ?>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($success)): ?>
                            <div style="color:green;">
                                <p><?php echo $success; ?></p>
                            </div>
                        <?php endif; ?>
                        <form id="postForm" action="" method="post" enctype="multipart/form-data">
                            <label>Title:<br>
                                <input type="text" name="title" required maxlength="100" placeholder="Enter a short title">
                            </label><br><br>
                            <label>Description:<br>
                                <textarea name="description" required></textarea>
                            </label><br><br>
                            <label>Location:<br>
                                <input type="text" name="location" id="locationInput" required placeholder="Select location on map" readonly style="background:#f9f9f9;cursor:pointer;">
                                <input type="hidden" name="latitude" id="latitudeInput">
                                <input type="hidden" name="longitude" id="longitudeInput">
                            </label><br>
                            <button type="button" id="openMapBtn" style="margin-bottom:10px;">Select Location</button>
                            <!-- Map Picker Modal -->
                            <div id="mapModal">
                                <div>
                                    <button id="closeMapBtn" type="button" style="position:absolute;top:10px;right:10px;font-size:18px;">&times;</button>
                                    <h3>Pick Location</h3>
                                    <div id="leafletMap"></div>
                                    <div style="margin-top:10px;">
                                        <label>Location Description:</label>
                                        <input type="text" id="modalLocationInput" style="width:100%;padding:6px;" placeholder="e.g. Near Palawan Capitol gate">
                                    </div>
                                    <button id="selectLocationBtn" type="button" style="margin-top:10px;">Select</button>
                                </div>
                            </div>
                            <label>Date:<br>
                                <input type="date" name="date" required>
                            </label><br><br>
                            <label>Time:<br>
                                <input type="time" name="time" required>
                            </label><br><br>
                            <label>Photo:<br>
                                <input type="file" name="photo" id="photoInput" accept="image/*" required>
                            </label><br><br>
                            <button type="submit">Post</button>
                        </form>
                </main>
                </section>
            </div>
            <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
            <script src="js/script.js"></script>
            <script>
                // Image preview
                const photoInput = document.getElementById('photoInput');
                const previewImg = document.getElementById('previewImg');
                const previewCard = document.getElementById('previewCard');
                const locationInputPreview = document.getElementById('locationInput');
                const previewLocation = document.getElementById('previewLocation');

                photoInput.addEventListener('change', function() {
                    const file = this.files[0];
                    if (file) {
                        const reader = new FileReader();
                        reader.onload = function(e) {
                            previewImg.src = e.target.result;
                            previewImg.style.display = 'block';
                            previewCard.style.display = 'block';
                        }
                        reader.readAsDataURL(file);
                    } else {
                        previewImg.src = '#';
                        previewImg.style.display = 'none';
                        if (!locationInputPreview.value) previewCard.style.display = 'none';
                    }
                });

                locationInputPreview.addEventListener('input', function() {
                    previewLocation.textContent = this.value;
                    if (this.value || photoInput.files.length > 0) {
                        previewCard.style.display = 'block';
                    } else {
                        previewCard.style.display = 'none';
                    }
                });

                // Modal logic with Leaflet map picker
                const mapModal = document.getElementById('mapModal');
                const openMapBtn = document.getElementById('openMapBtn');
                const closeMapBtn = document.getElementById('closeMapBtn');
                const selectLocationBtn = document.getElementById('selectLocationBtn');
                const modalLocationInput = document.getElementById('modalLocationInput');
                const locationInput = document.getElementById('locationInput');
                const latitudeInput = document.getElementById('latitudeInput');
                const longitudeInput = document.getElementById('longitudeInput');

                let map, marker;

                openMapBtn.addEventListener('click', function() {
                    mapModal.style.display = 'flex';
                    setTimeout(() => {
                        if (!map) {
                            map = L.map('leafletMap').setView([9.7395, 118.7435], 16); // Default to Palawan Capitol
                            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                                attribution: '&copy; OpenStreetMap contributors'
                            }).addTo(map);

                            map.on('click', function(e) {
                                if (marker) {
                                    marker.setLatLng(e.latlng);
                                } else {
                                    marker = L.marker(e.latlng).addTo(map);
                                }
                                latitudeInput.value = e.latlng.lat;
                                longitudeInput.value = e.latlng.lng;
                                modalLocationInput.value = `Lat: ${e.latlng.lat.toFixed(5)}, Lng: ${e.latlng.lng.toFixed(5)}`;
                            });
                        }
                        map.invalidateSize();
                        // If already selected, show marker
                        if (latitudeInput.value && longitudeInput.value) {
                            const latlng = [parseFloat(latitudeInput.value), parseFloat(longitudeInput.value)];
                            map.setView(latlng, 16);
                            if (!marker) marker = L.marker(latlng).addTo(map);
                            else marker.setLatLng(latlng);
                        }
                    }, 200);
                    modalLocationInput.value = locationInput.value;
                    modalLocationInput.focus();
                });

                closeMapBtn.addEventListener('click', function() {
                    mapModal.style.display = 'none';
                });

                selectLocationBtn.addEventListener('click', function() {
                    locationInput.value = modalLocationInput.value;
                    locationInput.dispatchEvent(new Event('input'));
                    mapModal.style.display = 'none';
                });

                // Also allow clicking the input to open modal
                locationInput.addEventListener('click', function() {
                    openMapBtn.click();
                });
            </script>
</body>

</html>