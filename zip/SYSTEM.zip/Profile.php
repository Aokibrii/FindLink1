<?php
session_start();
require 'config.php';

if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit();
}

$email = $_SESSION['email'];

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_name = $_POST['name'];
    $new_email = $_POST['email'];
    $profile_img = $_SESSION['profile_img']; // Default to current image

    // Handle file upload
    if (isset($_FILES['profile_img']) && $_FILES['profile_img']['error'] === UPLOAD_ERR_OK) {
        $img_name = basename($_FILES['profile_img']['name']);
        $target_dir = "uploads/";
        $target_file = $target_dir . uniqid() . "_" . $img_name;
        if (move_uploaded_file($_FILES['profile_img']['tmp_name'], $target_file)) {
            $profile_img = basename($target_file);
        }
    }

    // Update user in database
    $stmt = $connect->prepare("UPDATE users SET name=?, email=?, profile_img=? WHERE email=?");
    $stmt->bind_param("ssss", $new_name, $new_email, $profile_img, $email);
    $stmt->execute();
    $stmt->close();

    // Update session and redirect
    $_SESSION['name'] = $new_name;
    $_SESSION['email'] = $new_email;
    $_SESSION['profile_img'] = $profile_img;
    header("Location: Profile.php");
    exit();
}

// Always fetch the latest user data from the database
$stmt = $connect->prepare("SELECT name, email, profile_img FROM users WHERE email=?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($name, $email, $profile_img);
if ($stmt->fetch()) {
    $_SESSION['name'] = $name;
    $_SESSION['email'] = $email;
    $_SESSION['profile_img'] = $profile_img;
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <script src="https://kit.fontawesome.com/d5b87e9fae.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/user_page.css">
    <link rel="stylesheet" href="css/Profile.css">
</head>

<body>
    <div class="header">
        <div class="side-nav">
            <a href="" class="logo">
                <img src="images/Icon.jpg" class="logo-img">
            </a>
            <ul class="nav-links">
                <li><a href="user_page.php"><i class="fa-solid fa-house"></i>
                        <p>Home</p>
                    </a></li>
                <li><a href="Profile.php"><i class="fa-solid fa-circle-user"></i>
                        <p>Profile</p>
                    </a></li>
                <li><a href="Search.php"><i class="fa-solid fa-magnifying-glass"></i>
                        <p>Search for Lost and Found Items</p>
                    </a></li>
                <li><a href="Post_Lost_and_Found.php"><i class="fa-solid fa-paper-plane"></i>
                        <p>Post Lost and Found Items</p>
                    </a></li>
                <li><a href="Lost.php"><i class="fa-solid fa-question"></i>
                        <p>Lost Items Feed</p>
                    </a></li>
                <li><a href="Found.php"><i class="fa-solid fa-exclamation"></i>
                        <p>Found Items Feed</p>
                    </a></li>

                <div class="active"></div>
            </ul>
        </div>
    </div>
    <div class="user-profile">
        <h2>User Profile</h2>
        <div class="profile-info">
            <img src="<?php
                        echo (isset($_SESSION['profile_img']) && $_SESSION['profile_img'])
                            ? 'uploads/' . $_SESSION['profile_img']
                            : '';
                        ?>" alt="Profile Picture" class="profile-pic">
            <div>
                <h3><?php echo $_SESSION['name']; ?></h3>
                <p>Email: <?php echo $_SESSION['email']; ?></p>
            </div>
            <a href="#" class="edit-btn" onclick="openEditModal()">
                <i class="fa-solid fa-pen-to-square"></i> Edit Profile
            </a><br><br>
            <button type="button" class="logout-btn" onclick="confirmLogout().then((proceed) => { if (proceed) { window.location.href='logout.php'; } });">
                Logout
            </button>
        </div>
    </div>


    <div id="editModal">
        <div style="background:#fff; padding:30px; border-radius:8px; min-width:320px; position:relative; box-shadow:0 4px 24px rgba(0,0,0,0.15);">
            <h3>Edit Profile</h3>
            <form id="editProfileForm" method="post" action="Profile.php" enctype="multipart/form-data">
                <label>Name:</label>
                <input type="text" name="name" value="<?php echo $_SESSION['name']; ?>" required><br><br>
                <label>Email:</label>
                <input type="email" name="email" value="<?php echo $_SESSION['email']; ?>" required><br><br>
                <label>Profile Photo:</label>
                <input type="file" name="profile_img" accept="image/*"><br><br>
                <button type="submit">Save</button>
                <button type="button" onclick="closeEditModal()">Cancel</button>
            </form>
        </div>
    </div>

    <script>
        function openEditModal() {
            document.getElementById('editModal').classList.add('active');
        }

        function closeEditModal() {
            document.getElementById('editModal').classList.remove('active');
        }
    </script>
    <script src="js/script.js"></script>
</body>
<div id="logout-modal" class="modal">
    <div class="modal-content">
        <p>Are you sure you want to logout?</p>
        <div class="modal-buttons">
            <button id="logout-proceed-btn" class="btn proceed">Logout</button>
            <button id="logout-cancel-btn" class="btn cancel">Cancel</button>
        </div>
    </div>
</div>

</html>