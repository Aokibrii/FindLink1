<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lost and Found</title>
    <link rel="stylesheet" href="css/admin_page.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div>
        <main>
            <section class="welcome-section">
                <h1>ADMIN PANEL</h1>
                <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#logoutModal">Logout</button>
            </section>
        </main>
    </div>
    <div>
        <section class="admin-section">
            <h2>Admin Panel</h2>
            <div class="admin-buttons mb-3">
                <a href="add_item.php" class="btn btn-primary">Add Item</a>
                <a href="view_items.php" class="btn btn-secondary">View Items</a>
                <button class="btn btn-info" data-bs-toggle="modal" data-bs-target="#manageUsersModal">Manage Users</button>
            </div>
        </section>
    </div>


    <div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="logoutModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="logoutModalLabel">Confirm Logout</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to logout?
                </div>
                <div class="modal-footer">
                    <a href="logout.php" class="btn btn-danger">Logout</a>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap Manage Users Modal -->
    <div class="modal fade" id="manageUsersModal" tabindex="-1" aria-labelledby="manageUsersModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="manageUsersModalLabel">Manage Users</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php
                    // Connect to users_db
                    $conn = new mysqli("localhost", "root", "", "users_db");
                    if ($conn->connect_error) {
                        echo "<div class='alert alert-danger'>Connection failed: " . $conn->connect_error . "</div>";
                    } else {
                        // Handle user deletion
                        if (isset($_GET['delete_user'])) {
                            $delete_id = intval($_GET['delete_user']);
                            $conn->query("DELETE FROM users WHERE id=$delete_id");
                        }
                        // Handle user update
                        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_user'])) {
                            $edit_id = intval($_POST['user_id']);
                            $edit_name = $conn->real_escape_string($_POST['edit_name']);
                            $edit_email = $conn->real_escape_string($_POST['edit_email']);
                            $conn->query("UPDATE users SET name='$edit_name', email='$edit_email' WHERE id=$edit_id");
                        }
                        // Fetch users
                        $result = $conn->query("SELECT id, name, email FROM users");
                        echo "<table class='table table-bordered'><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Actions</th></tr></thead><tbody>";
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['name']}</td>
                        <td>{$row['email']}</td>
                        <td>
                            <button class='btn btn-sm btn-warning' onclick='editUser({$row['id']}, \"{$row['name']}\", \"{$row['email']}\")'>Edit</button>
                            <a href='?delete_user={$row['id']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Delete this user?\")'>Delete</a>
                        </td>
                    </tr>";
                        }
                        echo "</tbody></table>";
                        $conn->close();
                    }
                    ?>
                    <!-- Edit User Form (hidden, shown via JS) -->
                    <form id="editUserForm" method="post" class="d-none mt-3">
                        <input type="hidden" name="user_id" id="edit_user_id">
                        <div class="mb-2">
                            <label for="edit_name" class="form-label">Name</label>
                            <input type="text" name="edit_name" id="edit_name" class="form-control" required>
                        </div>
                        <div class="mb-2">
                            <label for="edit_email" class="form-label">Email</label>
                            <input type="email" name="edit_email" id="edit_email" class="form-control" required>
                        </div>
                        <button type="submit" name="edit_user" class="btn btn-success">Update User</button>
                        <button type="button" class="btn btn-secondary" onclick="hideEditForm()">Cancel</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editUser(id, name, email) {
            document.getElementById('editUserForm').classList.remove('d-none');
            document.getElementById('edit_user_id').value = id;
            document.getElementById('edit_name').value = name;
            document.getElementById('edit_email').value = email;
            // Scroll to form
            document.getElementById('editUserForm').scrollIntoView({
                behavior: "smooth"
            });
        }

        function hideEditForm() {
            document.getElementById('editUserForm').classList.add('d-none');
        }
    </script>
</body>

</html>