function showForm(formId) {
  document.getElementById("login-form").classList.remove("active");
  document.getElementById("register-form").classList.remove("active");
  document.getElementById(formId).classList.add("active");
}

document.addEventListener('DOMContentLoaded', function() {
  const logoutButton = document.getElementById('logout-proceed-btn');
  const cancelButton = document.getElementById('logout-cancel-btn');
  const logoutModal = document.getElementById('logout-modal');

  function confirmLogout() {
      logoutModal.style.display = 'block';
      return false; // Prevent default action
  }

  logoutButton.addEventListener('click', function() {
      window.location.href = 'logout.php';
  });

  cancelButton.addEventListener('click', function() {
      logoutModal.style.display = 'none';
  });

  window.confirmLogout = confirmLogout; // Expose function to global scope
});
async function confirmAction(message) {
  const modal = document.getElementById("confirmation-modal");
  const modalMessage = document.getElementById("confirmation-message");
  const proceedBtn = document.getElementById("confirm-proceed-btn");
  const cancelBtn = document.getElementById("confirm-cancel-btn");

  if (!modal || !modalMessage || !proceedBtn || !cancelBtn) {
    console.error("Required elements for confirmation modal are missing.");
    return false;
  }

  modalMessage.textContent = message;
  modal.style.display = "block";

  return new Promise((resolve) => {
    proceedBtn.onclick = () => {
      modal.style.display = "none";
      resolve(true); // Proceed with the action
    };

    cancelBtn.onclick = () => {
      modal.style.display = "none";
      resolve(false); // Cancel the action
    };
  });
}

function togglePasswordVisibility() {
  const passwordField = document.getElementById("password");
  const eyeIcon = document.getElementById("eye-close");

  if (passwordField.type === "password") {
    passwordField.type = "text"; // Show the password
    eyeIcon.src = "images/eye-open.png"; // Change the icon to an open eye
    eyeIcon.alt = "eye-open";
  } else {
    passwordField.type = "password"; // Hide the password
    eyeIcon.src = "images/eye-close.png"; // Change the icon back to a closed eye
    eyeIcon.alt = "eye-close";
  }
}
