<?php

session_start();
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lost and Found</title>
    <script src="https://kit.fontawesome.com/d5b87e9fae.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/user_page.css">
</head>

<body>
    <div class="header">
        <div class="side-nav">
            <a href="" class="logo">
                <img src="images/Icon.jpg" class="logo-img">
            </a>
            <ul class="nav-links">
                <li><a href="User_page.php"><i class="fa-solid fa-house"></i>
                        <p>Home</p>
                    </a></li>
                <li><a href="Profile.php"><i class="fa-solid fa-circle-user"></i>
                        <p>Profile</p>
                    </a></li>
                <li><a href="Search.php"><i class="fa-solid fa-magnifying-glass"></i>
                        <p>Search for Lost and Found Items</p>
                    </a></l>
                <li><a href="Post_Lost_and_Found.php"><i class="fa-solid fa-paper-plane"></i>
                        <p>Post Lost and Found Items</p>
                    </a></li>
                <li><a href="Lost.php"><i class="fa-solid fa-question"></i>
                        <p>Lost Items Feed</p>
                    </a></li>
                <li><a href="Found.php"><i class="fa-solid fa-exclamation"></i>
                        <p>Found Items Feed</p>
                    </a></li>
                <div class="active"></div>
        </div>
    </div>
    </div>
    </div>
    </div>
    <script src="js/script.js"></script>
</body>

</html>